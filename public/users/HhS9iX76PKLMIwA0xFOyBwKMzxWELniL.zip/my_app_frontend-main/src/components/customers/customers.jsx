import UnlimitedSubscriptionsList from "../unlimitedSubscriptions/unlimitedSubscriptionsList";
import CustomersList from "./customersList";
import LimitedSubscriptionsList from "../limitedSubscriptions/limitedSubscriptionsList";

export default function Customers(){
    return (
        <>
            <ul className="nav nav-tabs" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                    <button className="nav-link active" id="customers-tab" data-bs-toggle="tab"
                            data-bs-target="#customers-tab-pane" type="button" role="tab" aria-controls="customers-tab-pane"
                            aria-selected="true">Клиенты
                    </button>
                </li>
                <li className="nav-item" role="presentation">
                    <button className="nav-link" id="subscriptions-tab" data-bs-toggle="tab"
                            data-bs-target="#subscriptions-tab-pane" type="button" role="tab" aria-controls="subscriptions-tab-pane"
                            aria-selected="false">Абонименты
                    </button>
                </li>

                <li className="nav-item" role="presentation">
                    <button className="nav-link" id="workouts-tab" data-bs-toggle="tab"
                            data-bs-target="#workouts-tab-pane" type="button" role="tab" aria-controls="workouts-tab-pane"
                            aria-selected="false">Тренировки с тренерами
                    </button>
                </li>

            </ul>
            <div className="tab-content" id="myTabContent">
                <div className="tab-pane fade show active" id="customers-tab-pane" role="tabpanel" aria-labelledby="customers-tab"
                     tabIndex="0"><CustomersList/>
                </div>
                <div className="tab-pane fade" id="subscriptions-tab-pane" role="tabpanel" aria-labelledby="subscriptions-tab"
                     tabIndex="1"><UnlimitedSubscriptionsList/>
                </div>
                <div className="tab-pane fade" id="workouts-tab-pane" role="tabpanel" aria-labelledby="workouts-tab"
                     tabIndex="2"><LimitedSubscriptionsList/>
                </div>
            </div>
        </>
    )
}