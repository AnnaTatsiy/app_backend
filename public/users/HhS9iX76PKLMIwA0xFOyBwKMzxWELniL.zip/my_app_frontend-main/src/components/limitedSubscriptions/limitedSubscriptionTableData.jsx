//  <td>{sub.coach.surname} {sub.coach.name} {sub.coach.patronymic}</td>

export default function LimitedSubscriptionTableData({sub}){

    return (
        <>
            <tr>
                <td>{sub.customer.surname} {sub.customer.name} {sub.customer.patronymic}</td>
                <td></td>
                <td>{sub.limited_price_list.amount_workout}</td>
                <td>{new Date(sub.open).toLocaleDateString()}</td>
            </tr>
        </>
    )
}