import CoachesList from "./coachesList";
import LimitedPriceLists from "../limitedPriceLists/limitedPriceLists";

export default function Coaches() {

    return (
        <>
            <ul className="nav nav-tabs" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                    <button className="nav-link active" id="coashes-tab" data-bs-toggle="tab"
                            data-bs-target="#coashes-tab-pane" type="button" role="tab" aria-controls="coashes-tab-pane"
                            aria-selected="true">Тренеры
                    </button>
                </li>
                <li className="nav-item" role="presentation">
                    <button className="nav-link" id="price-tab" data-bs-toggle="tab"
                            data-bs-target="#price-tab-pane" type="button" role="tab" aria-controls="price-tab-pane"
                            aria-selected="false">Прайс на тренировки
                    </button>
                </li>
            </ul>
            <div className="tab-content" id="myTabContent">
                <div className="tab-pane fade show active" id="coashes-tab-pane" role="tabpanel" aria-labelledby="coashes-tab"
                     tabIndex="0"><CoachesList/>
                </div>
                <div className="tab-pane fade" id="price-tab-pane" role="tabpanel" aria-labelledby="price-tab"
                     tabIndex="1"><LimitedPriceLists/>
                </div>

            </div>
        </>
    )

}
