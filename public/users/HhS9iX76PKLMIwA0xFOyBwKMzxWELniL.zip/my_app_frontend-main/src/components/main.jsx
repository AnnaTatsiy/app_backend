export default function Main(){
    return (
        <p>Main</p>
    )
}