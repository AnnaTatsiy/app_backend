import {NavLink} from "react-router-dom";

// компонент навигационной панели
export default function Nav(){

    const setActive = ({isActive}) => "link-item " + (isActive ? "active" : "");

    return(
        <>
            <nav className="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
                <div className="container-fluid">
                    <div style={{width: "90%", margin: "auto"}}>
                        <div className="navbar-collapse">
                            <ul className="navbar-nav fs-5">
                                <li className="nav-item p-2">
                                    <NavLink to="/" className={setActive}>Расписание</NavLink>
                                    <NavLink to="/customers" className={setActive}>Клиенты</NavLink>
                                    <NavLink to="/coaches" className={setActive}>Тренеры</NavLink>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </>
    )
}