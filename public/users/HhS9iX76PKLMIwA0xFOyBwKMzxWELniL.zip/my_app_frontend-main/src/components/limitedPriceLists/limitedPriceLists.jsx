import {useDispatch, useSelector} from "react-redux";
import {useEffect, useState} from "react";
import {getAllLimitedPriceLists, getLimitedPriceLists} from "../../actions/limitedPriceLists/action";
import {getAllCoaches} from "../../actions/coaches/action";
import {Table} from "react-bootstrap";
import CoachOption from "../coaches/coachOption";
import ReactPaginate from "react-paginate";
import LimitedPriceListTableData from "./limitedPriceListTableData";

export default function LimitedPriceLists(){

    const dispatch = useDispatch();

    // текущая страница
    const [page, setPage] = useState(1);

    // вызов ф-ии получения прайс листа от сервера
    useEffect(() => {
        dispatch(getLimitedPriceLists(page));
    }, [dispatch, page])

    //все тренеры для dataList
    const dataList = useSelector(state => state.coaches.dataList);

    useEffect(() => {
        dispatch(getAllCoaches())
    }, [dispatch, dataList])

    useEffect(() => {
        dispatch(getAllLimitedPriceLists())
    }, [dispatch, dataList])

    const prices = useSelector(state => state.limitedPriceLists.list);
    const fullPriceLists = useSelector(state => state.limitedPriceLists.fullList);

    //номер последней страницы
    const lastPage = useSelector(state => state.limitedPriceLists.lastPage);

    // состояние для фильтрации
    const [searchValue, setSearchValue] = useState('');

    //обработчик клика по элементам пагинации
    const handlePageClick = (e) => {
        setPage(e.selected + 1);
        setSearchValue('');
    }

    // список отфильтрованных прайс листов по серии-номеру паспорта тренера
    const filteredPrices = fullPriceLists.filter(price =>
        price.coach.passport.includes(searchValue)
    );

    //проверка отобразить всех или по критерию поиска
    const viewPrices = ((searchValue.length !== 0) ? filteredPrices : prices);

    return (
        <>
                <div className={"row mt-4 mb-3"}>
                    <div className="form-floating col-5">
                        <input
                            className="form-control"
                            type={"text"} value={searchValue}
                            list="datalistOptions" id="exampleDataList"
                            placeholder="Type to search..."
                            onChange={(e) => {
                                setSearchValue(e.target.value);
                            }}
                            name={"passport"}/>
                        <datalist id="datalistOptions">
                            {dataList.map((item) => (
                                <CoachOption key={item.id} coach={item}/>
                            ))}
                        </datalist>
                        <label htmlFor="exampleDataList" className="form-label p-3 ps-4 text-secondary">ФИО или серия-номер
                            паспорта:</label>
                    </div>
                </div>

            <Table>
                <thead>
                <tr>
                    <th>ФИО тренера</th>
                    <th>Кол-во тренировок</th>
                    <th>Стоимость</th>
                </tr>
                </thead>
                <tbody>
                {viewPrices.map((item) => (
                    <LimitedPriceListTableData key={item.id} price={item}/>
                ))}
                </tbody>
            </Table>

            <div className={"d-flex justify-content-end"}>
                <ReactPaginate
                    previousLabel={'«'}
                    breakLabel={'...'}
                    nextLabel={'»'}
                    pageCount={lastPage}
                    marginPagesDisplayed={5}
                    pageRangeDisplayed={8}
                    onPageChange={handlePageClick}
                    containerClassName={'pagination'}
                    pageClassName={'page-item'}
                    pageLinkClassName={'page-link'}
                    previousClassName={'page-item'}
                    previousLinkClassName={'page-link'}
                    nextClassName={'page-item'}
                    nextLinkClassName={'page-link'}
                    breakClassName={'page-item'}
                    breakLinkClassName={'page-link'}
                    activeClassName={'active'}
                />
            </div>
        </>
    )
}