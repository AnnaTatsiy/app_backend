import './App.css';
import Footer from "./components/footer";
import Nav from "./components/nav";
import {Route, Routes} from "react-router-dom";
import Schedule from "./components/schedule/schedule";
import Coaches from "./components/coaches/coaches";
import Customers from "./components/customers/customers";

// главный компонент приложения
function App() {
  return (
    <>
      <Nav/>
      <div className="container-fluid">
        <div className="row-sm mt-5 p-3 container-fluid-style">
          <div className="p-4 bg-white m-3 border-warning-top border-warning-bottom">
            <div className="container">
                <Routes>
                    <Route path={"/"} element={<Schedule/>}/>
                    <Route path={"/customers"} element={<Customers/>}/>
                    <Route path={"/coaches"} element={<Coaches/>}/>
                </Routes>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </>
  );
}

export default App;
