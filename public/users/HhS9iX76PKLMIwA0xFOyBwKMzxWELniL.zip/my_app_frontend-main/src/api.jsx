import axios from "axios";

export default axios.create(
{
        // адрес сервера
        baseURL: "http://127.0.0.1:8000",

        // заголовки запросов
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            "Content-type": "application/json"}
    }
)