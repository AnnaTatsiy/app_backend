import api from '../api';

class CustomersService {

    // получить список всех клиентов
    async getAllCustomers() {
        return await api.get('/customers/get-all');
    }

    // получить список всех клиентов постранично
    async getAll(number) {
        return await api.get('/customers/all', {params: {page: number}});
    }

    // добавить клиента
    async add(customer){
        return api.post('/customers/add', customer);
    }

    // редактирование клиента
    async edit(customer){
        return api.post('/customers/edit', customer);
    }
}

export default new CustomersService();