import api from '../api';

class LimitedPriceListsService{

    //получить прайс лист
    async getAllLimitedPriceLists(){
        return await api.get('/limited-price-lists/get-all');
    }

    //получить прайс лист постранично
    async getAll(number){
        return await api.get('/limited-price-lists/all', {params: {page: number}});
    }
}

export default new LimitedPriceListsService();