import api from '../api';

class CoachesService {

    // получить список всех тренеров
    async getAllCoaches() {
        return await api.get('/coaches/get-all');
    }

    // получить список всех тренеров постранично
    async getAll(number) {
        return await api.get('/coaches/all', {params: {page: number}});
    }

    // добавить тренера
    async add(coaches){
        return api.post('/coaches/add', coaches)
    }

    // редактирование тренера
    async edit(coaches){
        return api.post('/coaches/edit', coaches)
    }
}

export default new CoachesService();