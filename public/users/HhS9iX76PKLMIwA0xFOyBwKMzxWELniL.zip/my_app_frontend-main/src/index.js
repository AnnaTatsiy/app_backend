import React from 'react';
import ReactDOM from 'react-dom/client';
import {configureStore} from '@reduxjs/toolkit'
import {BrowserRouter as Router} from 'react-router-dom';
import {Provider} from 'react-redux'
import App from './App';

import './lib/bootstrap/css/bootstrap.min.css';

import scheduleReducer from "./reducers/schedules/scheduleReducer";
import customersReducer from "./reducers/customers/customerReducer";
import coachesReducer from "./reducers/coaches/coachesReducer"
import limitedPriceListReducer from "./reducers/limitedPriceLists/limitedPriceListReducer";
import unlimitedSubscriptionReducer from "./reducers/unlimitedSubscriptions/unlimitedSubscriptionReducer";
import limitedSubscriptionReducer from "./reducers/limitedSubscriptions/limitedSubscriptionReducer";


const store = configureStore({
    reducer: {
        schedules: scheduleReducer,
        customers: customersReducer,
        coaches: coachesReducer,
        limitedPriceLists: limitedPriceListReducer,
        unlimitedSubscription: unlimitedSubscriptionReducer,
        limitedSubscription: limitedSubscriptionReducer
    }
})

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
      <Router>
            <App/>
      </Router>
  </Provider>
);

