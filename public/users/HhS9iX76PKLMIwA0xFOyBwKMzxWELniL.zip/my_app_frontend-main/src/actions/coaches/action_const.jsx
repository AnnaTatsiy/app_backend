export const GET_ALL_COACHES = 'GET_ALL_COACHES';
export const GET_COACHES = 'GET_COACHES';
export const ADD_COACH = 'ADD_COACH';
export const EDIT_COACH = 'EDIT_COACH';
